const express = require('express');
const router = express.Router();

/* ===================== AUTH (FIX DEFINITIVO) ===================== */
let verifyToken, requireRoles;

try {
  const m = require('../middleware/verifyToken');
  verifyToken = m.verifyToken;
  requireRoles = m.requireRoles || (() => (req, _res, next) => next());
} catch (e) {
  console.warn('[adminUsersFinanceRoutes] verifyToken não encontrado, usando fallback');
  verifyToken = (req, _res, next) => next();
  requireRoles = () => (req, _res, next) => next();
}

/* ===================== CONTROLLERS ===================== */
const financeCtrl = require('../controllers/adminUsersFinanceController');
const userActionsCtrl = require('../controllers/adminUserActionsController');

/* ===================== ROTAS ===================== */

/**
 * GET /api/admin/users/finance
 * Lista usuários com status financeiro (admin)
 */
router.get(
  '/users/finance',
  verifyToken,
  requireRoles('admin'),
  financeCtrl.listUsersFinance
);

/**
 * GET /api/admin/users/:id/finance
 * Detalhe financeiro de um usuário
 */
router.get(
  '/users/:id/finance',
  verifyToken,
  requireRoles('admin'),
  financeCtrl.getUserFinance
);

/**
 * PATCH /api/admin/users/:id/financial-status
 * Atualiza status financeiro do usuário
 */
router.patch(
  '/users/:id/financial-status',
  verifyToken,
  requireRoles('admin'),
  userActionsCtrl.updateFinancialStatus
);

module.exports = router;
