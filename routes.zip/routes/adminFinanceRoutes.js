// routes/adminFinanceRoutes.js
const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/verifyToken');
let requireRoles = null;
try { requireRoles = require('../middleware/verifyToken').requireRoles; } catch {}
const can = requireRoles ? requireRoles('superadmin','admin','financeiro','admin-ops','cfo','coo') : (_req,_res,next)=>next();

router.use(verifyToken, can);

/* helpers de data */
const startOfDay   = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
const startOfWeek  = d => { const x=new Date(startOfDay(d)); const wd=(x.getDay()+6)%7; x.setDate(x.getDate()-wd); return x; }; // segunda
const startOfMonth = d => new Date(d.getFullYear(), d.getMonth(), 1);

function safeRequire(paths) {
  for (const p of paths) { try { return require(p); } catch {} }
  return null;
}

const Payment   = safeRequire(['../models/Payment','../models/pagamento','../models/Pagamento']);
const Order     = safeRequire(['../models/Order','../models/order','../models/Pedido','../models/pedido']);

async function sumPaid(from) {
  const now = new Date();
  const queryDate = { $gte: from, $lte: now };

  // tenta pagamentos
  if (Payment) {
    const orPaid = [{ status: 'paid' }, { status: 'approved' }, { status: 'succeeded' }];
    const byDate = { $or: [ { paidAt: queryDate }, { createdAt: queryDate }, { updatedAt: queryDate } ] };
    const q = { $and: [ { $or: orPaid }, byDate ] };
    const docs = await Payment.find(q).select('amount valor total').lean();
    return docs.reduce((acc, d) => acc + Number(d.amount ?? d.valor ?? d.total ?? 0), 0);
  }

  // tenta pedidos
  if (Order) {
    const orPaid = [{ status: 'paid' }, { status: 'pago' }, { status: 'completed' }];
    const byDate = { $or: [ { paidAt: queryDate }, { createdAt: queryDate }, { updatedAt: queryDate } ] };
    const q = { $and: [ { $or: orPaid }, byDate ] };
    const docs = await Order.find(q).select('amount valor total').lean();
    return docs.reduce((acc, d) => acc + Number(d.amount ?? d.valor ?? d.total ?? 0), 0);
  }

  return 0;
}

router.get('/summary', async (_req, res) => {
  try {
    const now = new Date();
    const [today, week, month] = await Promise.all([
      sumPaid(startOfDay(now)),
      sumPaid(startOfWeek(now)),
      sumPaid(startOfMonth(now)),
    ]);
    return res.json({ today, week, month });
  } catch (e) {
    console.error('[finance.summary]', e);
    return res.status(500).json({ message: 'Falha ao calcular resumo' });
  }
});

router.get('/transactions', async (_req, res) => {
  try {
    // tenta pegar últimos pagamentos ou pedidos
    if (Payment) {
      const items = await Payment.find().sort({ createdAt: -1 }).limit(50).lean();
      return res.json({ items: items.map(d => ({
        _id: d._id, description: d.description || 'Pagamento', amount: Number(d.amount ?? d.valor ?? d.total ?? 0), createdAt: d.createdAt,
      })) });
    }
    if (Order) {
      const items = await Order.find().sort({ createdAt: -1 }).limit(50).lean();
      return res.json({ items: items.map(d => ({
        _id: d._id, description: d.description || 'Pedido', amount: Number(d.amount ?? d.valor ?? d.total ?? 0), createdAt: d.createdAt,
      })) });
    }
    return res.json({ items: [] });
  } catch (e) {
    console.error('[finance.transactions]', e);
    return res.status(500).json({ message: 'Falha ao listar transações' });
  }
});

module.exports = router;
