const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/verifyToken');
const BugsController = require('../controllers/bugsController');

// 📌 Reportar bug (qualquer usuário)
router.post('/report', (req, res, next) => {
  if (req.headers.authorization) {
    return verifyToken(req, res, () => next());
  }
  return next();
}, BugsController.report);

// 🔒 Endpoints admin (somente admin)
router.use(verifyToken, (req, res, next) => {
  if ((req.user?.role || '').toLowerCase() !== 'admin') return res.status(403).json({ message: 'Acesso negado' });
  next();
});

router.get('/', BugsController.list);
router.get('/count', BugsController.countOpen);
router.get('/:id', BugsController.get);
router.get('/:id/logs', BugsController.logs);
router.post('/:id/start', BugsController.start);
router.post('/:id/resolve', BugsController.resolve);
router.post('/:id/reopen', BugsController.reopen);

module.exports = router;
