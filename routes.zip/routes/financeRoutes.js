const express = require('express');
const router = express.Router();

const financeCtrl = require('../controllers/financeController');
const { verifyToken, requireRoles } = require('../middleware/authMiddleware');

/* =====================================================
   RESUMO FINANCEIRO
===================================================== */

router.get(
  '/summary',
  verifyToken,
  requireRoles('profissional'),
  financeCtrl.summary
);

/* =====================================================
   LISTA DE TRANSAÇÕES
===================================================== */

router.get(
  '/transactions',
  verifyToken,
  requireRoles('profissional'),
  financeCtrl.listTransactions
);

/* =====================================================
   CONSULTAR COMISSÃO
===================================================== */

router.get(
  '/commission',
  verifyToken,
  requireRoles('profissional'),
  financeCtrl.getCommission
);

/* =====================================================
   ALTERAR PLANO
===================================================== */

router.post(
  '/change-plan',
  verifyToken,
  requireRoles('profissional'),
  financeCtrl.changePlan
);

/* =====================================================
   PAGAR COMISSÃO
   (gera pagamento PIX/cartão)
===================================================== */

router.post(
  '/pay-commission',
  verifyToken,
  requireRoles('profissional'),
  financeCtrl.payCommission
);

module.exports = router;