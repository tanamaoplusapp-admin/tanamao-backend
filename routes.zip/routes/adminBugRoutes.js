// routes/adminBugRoutes.js
const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/verifyToken');
let requireRoles = null;
try { requireRoles = require('../middleware/verifyToken').requireRoles; } catch {}
const can = requireRoles ? requireRoles('superadmin','admin','cto','qa','suporte','admin-ops') : (_req,_res,next)=>next();

let BugReport = null;
try { BugReport = require('../models/BugReport'); } catch {}

router.use(verifyToken, can);

router.get('/count', async (req, res) => {
  try {
    if (!BugReport) return res.json({ count: 0 });
    const status = (req.query.status || 'aberto').toString();
    const count = await BugReport.countDocuments({ status });
    return res.json({ count });
  } catch (e) {
    console.error('[adminBugs.count]', e);
    return res.status(500).json({ message: 'Falha ao contar bugs' });
  }
});

router.get('/', async (req, res) => {
  try {
    if (!BugReport) return res.json({ items: [], total: 0 });
    const { q, status, severity, page = 1, limit = 50 } = req.query;
    const query = {};
    if (status)   query.status = status;
    if (severity) query.severity = severity;
    if (q)        query.$text = { $search: String(q) };

    const l = Math.min(Number(limit) || 50, 200);
    const p = Math.max(Number(page) || 1, 1);

    const items = await BugReport.find(query).sort({ createdAt: -1 }).skip((p-1)*l).limit(l).lean();
    const total = await BugReport.countDocuments(query);
    return res.json({ items, total, page: p, limit: l });
  } catch (e) {
    console.error('[adminBugs.list]', e);
    return res.status(500).json({ message: 'Falha ao listar bugs' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    if (!BugReport) return res.status(404).json({ message: 'Bug não encontrado' });
    const item = await BugReport.findById(req.params.id).lean();
    if (!item) return res.status(404).json({ message: 'Bug não encontrado' });
    return res.json(item);
  } catch (e) {
    console.error('[adminBugs.get]', e);
    return res.status(500).json({ message: 'Falha ao obter bug' });
  }
});

router.post('/:id/resolve', async (req, res) => {
  try {
    if (!BugReport) return res.status(404).json({ message: 'Bug não encontrado' });
    const item = await BugReport.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Bug não encontrado' });
    item.status = 'resolvido';
    await item.save();
    return res.json(item);
  } catch (e) {
    console.error('[adminBugs.resolve]', e);
    return res.status(500).json({ message: 'Falha ao resolver bug' });
  }
});

module.exports = router;
