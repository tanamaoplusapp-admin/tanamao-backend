console.log('🔥 AUTH ROUTES REALMENTE CARREGADO 🔥');

const express = require('express');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const router = express.Router();

/* ===== Models necessários para registro profissional ===== */

const User = require('../models/user');
const Profissional = require('../models/Profissional');

/* ===== UserController (fallback/legado) ===== */

let userCtrl = {};
try {
  userCtrl = require('../controllers/userController');
} catch (_) {
  userCtrl = {};
}

const {
  registerUser,
  verifyEmail,
  authUser,
  forgotPassword,
  resetPassword,
} = userCtrl;

/* ===== Auth (multi-roles) Controller ===== */

let authMulti = null;
try {
  authMulti = require('../controllers/authController');
} catch (err) {
  console.warn('[authRoutes] authController não encontrado:', err.message);
  authMulti = null;
}

/* 🔥 fallback direto do controller */

let authController = null;
try {
  authController = require('../controllers/authController');
} catch (_) {
  authController = null;
}

const registerGeneric = authMulti?.registerGeneric;
const registerEmpresa = authMulti?.registerEmpresa;
const loginMulti = authMulti?.login;

/* 🔥 fallback seguro para me */

const meHandler = authMulti?.me || authController?.me;

/* ===== Rate Limits ===== */

const createLimiter = (maxPer15m) =>
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: maxPer15m,
    standardHeaders: true,
    legacyHeaders: false,
  });

/* ===========================================================
   ===== ROTAS PÚBLICAS
=========================================================== */

if (registerGeneric) {
  router.post('/register', createLimiter(100), registerGeneric);
} else if (registerUser) {
  router.post('/register', createLimiter(100), registerUser);
}

/* ===========================================================
   ===== REGISTER PROFISSIONAL
=========================================================== */

router.post('/register-profissional', createLimiter(100), async (req, res) => {
  try {

    const {
      nome,
      email,
      telefone,
      cpf,
      senha,
      profissoes,
      banco,
      agencia,
      conta,
      tipoConta,
      pix,
      photoUrl,
    } = req.body;

    if (!nome || !email || !cpf || !telefone || !senha) {
      return res.status(400).json({
        ok: false,
        message: 'Dados obrigatórios ausentes',
      });
    }

    const emailNorm = String(email).trim().toLowerCase();

    const existingUser = await User.findOne({ email: emailNorm });

    if (existingUser) {
      return res.status(400).json({
        ok: false,
        message: 'E-mail já cadastrado',
      });
    }

    const existingCpf = await Profissional.findOne({ cpf });

    if (existingCpf) {
      return res.status(400).json({
        ok: false,
        message: 'CPF já cadastrado',
      });
    }

    /* =============================
       CRIA USER
    ============================= */

    const user = await User.create({
      name: nome,
      email: emailNorm,
      password: senha,
      role: 'profissional',
      phone: telefone,
      cpf,
      avatar: photoUrl || null,
    });

    /* =============================
       CRIA PERFIL PROFISSIONAL
    ============================= */

    const profissional = await Profissional.create({
      userId: user._id,
      name: nome,
      email: emailNorm,
      password: user.password,
      cpf,
      phone: telefone,
      avatar: photoUrl || null,
      especialidades: profissoes || [],
      bank: banco
        ? {
            banco,
            agencia,
            conta,
            tipoConta,
            pix,
            titular: nome,
            documento: cpf,
            updatedAt: new Date(),
          }
        : undefined,
    });

    /* =============================
       TOKEN (CORRIGIDO)
    ============================= */

    const token = jwt.sign(
      {
        sub: user._id,
        userId: user._id,
        id: user._id, // compatibilidade com tokens antigos
        role: user.role,
      },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.status(201).json({
      ok: true,
      message: 'Profissional cadastrado com sucesso',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
      },
      profissional,
    });

  } catch (error) {

    console.error('register-profissional error:', error);

    return res.status(500).json({
      ok: false,
      message: 'Erro ao cadastrar profissional',
      details: error.message,
    });
  }
});

/* ===========================================================
   ===== OUTRAS ROTAS
=========================================================== */

if (verifyEmail) {
  router.get('/verify-email/:token', verifyEmail);
}

if (forgotPassword) {
  router.post('/forgot-password', createLimiter(60), forgotPassword);
}

if (resetPassword) {
  router.post('/reset-password/:token', createLimiter(60), resetPassword);
}

if (loginMulti) {
  router.post('/login', createLimiter(300), loginMulti);
  console.log('[authRoutes] rota POST /login carregada com authMulti.login');
} else if (authUser) {
  router.post('/login', createLimiter(300), authUser);
  console.log('[authRoutes] rota POST /login carregada com authUser');
} else {
  console.warn('[authRoutes] Nenhum handler de login encontrado!');
}

if (registerEmpresa) {
  router.post('/register-empresa', createLimiter(60), registerEmpresa);
}

/* ===========================================================
   ===== ROTAS PROTEGIDAS
=========================================================== */

let authMiddleware;
try {
  authMiddleware = require('../middlewares/authMiddleware');
} catch (_) {
  authMiddleware = null;
}

const { verifyToken } = require('../middleware/verifyToken');

if (meHandler) {
  if (authMiddleware) {
    router.get('/me', authMiddleware, createLimiter(1200), meHandler);
  } else {
    router.get('/me', verifyToken, createLimiter(1200), meHandler);
  }
} else {
  console.warn('[authRoutes] Rota /me não registrada - handler não encontrado');
}

module.exports = router;