const express = require('express');
const router = express.Router();

const { MercadoPagoConfig, Payment, Preference } = require('mercadopago');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const { celebrate, Joi, Segments } = require('celebrate');

/* =====================================================
   ✅ IMPORT SEGURO DO MIDDLEWARE (CORREÇÃO REAL)
===================================================== */
const auth = require('../middleware/verifyToken');

const verifyToken = auth.verifyToken;
const requireRoles = auth.requireRoles;

// fallback seguro caso requireVerified não exista
const requireVerified =
  typeof auth.requireVerified === 'function'
    ? auth.requireVerified
    : (_req, _res, next) => next();

/* ===================================================== */

const Order = require('../models/order');
const Company = require('../models/company');
const config = require('../config/env');

/* ----------------------- Limites / Config ----------------------- */
const webhookLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
});

if (!process.env.MERCADO_PAGO_ACCESS_TOKEN) {
  console.warn('[paymentRoutes] MERCADO_PAGO_ACCESS_TOKEN ausente no .env');
}

const mp = new MercadoPagoConfig({
  accessToken: process.env.MERCADO_PAGO_ACCESS_TOKEN,
});

/* ----------------------- Helpers / Comissão ----------------------- */
const norm = (s) =>
  String(s || '')
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .toLowerCase();

function calcularComissao(valor, porte, user) {
  const tipo = (user?.role || user?.tipo || '').toLowerCase();

  if (tipo === 'motorista') {
    const v = Number(valor);
    return { comissao: 0, valorLiquido: v, porcentagem: 0 };
  }

  let porcentagem = 0;

  if (tipo === 'empresa') {
    const p = norm(porte);
    const tabela = config.payments?.commission?.empresa || {
      mei: 0.03,
      pequeno: 0.05,
      medio: 0.07,
      grande: 0.10,
    };

    if (p === 'mei') porcentagem = tabela.mei;
    else if (['pequena', 'pequeno'].includes(p)) porcentagem = tabela.pequeno;
    else if (['media', 'medio'].includes(p)) porcentagem = tabela.medio;
    else if (p === 'grande') porcentagem = tabela.grande;
    else porcentagem = tabela.pequeno;
  }

  if (tipo === 'profissional') {
    const base = Number(config.payments?.commission?.profissional?.base ?? 0);
    const thr = Number(config.payments?.commission?.profissional?.bonusThreshold ?? 3500);
    const rate = Number(config.payments?.commission?.profissional?.bonusRate ?? 0.10);
    const lucro = Number(user?.lucroAcumulado || 0);
    porcentagem = lucro > thr ? rate : base;
  }

  const v = Number(valor);
  const comissao = Number((v * porcentagem).toFixed(2));
  const valorLiquido = Number((v - comissao).toFixed(2));
  return { comissao, valorLiquido, porcentagem };
}

/* ----------------------- Utils ----------------------- */
const mkIdemKey = (prefix = 'pix') =>
  `${prefix}-${crypto.randomUUID?.() || crypto.randomBytes(16).toString('hex')}`;

const asNumber = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : NaN;
};

const objectId = Joi.string().hex().length(24);

/* ----------------------- Validations ----------------------- */
const validatePixBody = celebrate({
  [Segments.BODY]: Joi.object({
    value: Joi.number().min(0.5).required(),
    payer: Joi.object({
      email: Joi.string().email().required(),
      first_name: Joi.string().required(),
      last_name: Joi.string().allow('', null),
      identification: Joi.object({
        type: Joi.string().valid('CPF', 'CNPJ').optional(),
        number: Joi.string().optional(),
      }).optional(),
    }).required(),
    products: Joi.array().min(1).required(),
    description: Joi.string().allow('', null),
    empresaId: objectId.required(),
    motoristaId: objectId.allow('', null),
  }),
});

const validateCardBody = celebrate({
  [Segments.BODY]: Joi.object({
    unit_price: Joi.number().min(0.5).required(),
    payer: Joi.object({
      email: Joi.string().email().required(),
      name: Joi.string().allow('', null),
    }).required(),
    products: Joi.array().min(1).required(),
    description: Joi.string().allow('', null),
    empresaId: objectId.required(),
    motoristaId: objectId.allow('', null),
  }),
});

const validateStatusParams = celebrate({
  [Segments.PARAMS]: Joi.object({
    paymentId: Joi.alternatives(Joi.string(), Joi.number()).required(),
  }),
});

/* ----------------------- PIX ----------------------- */
const handlePix = async (req, res) => {
  try {
    const { value, payer, products, description, empresaId, motoristaId } = req.body;
    const amount = asNumber(value);

    const company = await Company.findById(empresaId).select('porteEmpresa collector_id');
    if (!company) return res.status(404).json({ error: 'Empresa não encontrada' });
    if (!company.collector_id) {
      return res.status(400).json({ error: 'Empresa sem collector_id configurado' });
    }

    const { comissao, valorLiquido, porcentagem } =
      calcularComissao(amount, company.porteEmpresa, req.user);

    const payment = await new Payment(mp).create({
      body: {
        transaction_amount: amount,
        payment_method_id: 'pix',
        description: description || 'Pagamento Tá na Mão',
        payer,
        application_fee: comissao,
        sponsor_id: company.collector_id,
        metadata: { empresaId, comissao, porcentagem, valorLiquido },
      },
      requestOptions: { idempotencyKey: mkIdemKey('pix') },
    });

    const tx = payment?.point_of_interaction?.transaction_data;
    if (!tx?.qr_code) {
      return res.status(502).json({ error: 'Falha ao gerar QR Code' });
    }

    const order = await Order.create({
      clienteId: req.userId,
      empresaId,
      motoristaId: motoristaId || undefined,
      products,
      total: amount,
      formaPagamento: 'Pix',
      comissao,
      valorLiquido,
      pagamento: {
        metodo: 'pix',
        idPagamento: payment.id,
        status: payment.status,
        qr_code: tx.qr_code,
        qr_code_base64: tx.qr_code_base64,
      },
    });

    return res.json({
      id: payment.id,
      qr_code: tx.qr_code,
      qr_code_base64: tx.qr_code_base64,
      pedidoId: order._id,
    });
  } catch (err) {
    console.error('[PIX]', err);
    return res.status(500).json({ error: 'Erro ao gerar Pix' });
  }
};

router.post(
  '/pix',
  verifyToken,
  requireVerified,
  requireRoles('empresa', 'profissional'),
  validatePixBody,
  handlePix
);

/* ----------------------- STATUS ----------------------- */
router.get('/:paymentId/status', verifyToken, validateStatusParams, async (req, res) => {
  const payment = await new Payment(mp).get({ id: req.params.paymentId });
  res.json(payment);
});

/* ----------------------- WEBHOOK ----------------------- */
router.post('/webhook', webhookLimiter, async (_req, res) => {
  return res.status(200).json({ received: true });
});

/* ----------------------- CARTÃO ----------------------- */
router.post(
  '/card',
  verifyToken,
  requireVerified,
  requireRoles('empresa', 'profissional'),
  validateCardBody,
  async (_req, res) => {
    return res.status(501).json({ message: 'Checkout cartão ativo via Preference.' });
  }
);

module.exports = router;
