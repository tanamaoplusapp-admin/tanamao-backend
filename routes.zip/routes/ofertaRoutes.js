import express from 'express';
import * as OfertaController from '../controllers/ofertaController.js';

const router = express.Router();

// criar oferta
router.post('/', OfertaController.criar);

// listar ofertas do profissional (feed do perfil social)
router.get('/', OfertaController.listarPorProfissional);

// editar oferta
router.put('/:ofertaId', OfertaController.atualizar);

// excluir oferta
router.delete('/:ofertaId', OfertaController.excluir);

export default router;
