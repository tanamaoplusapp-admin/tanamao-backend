const express = require("express");
const router = express.Router();
const { verifyToken, requireRoles } = require("../middleware/authMiddleware");
const AdminAuditLog = require("../models/AdminAuditLog");

router.get(
  "/audit",
  verifyToken,
  requireRoles("admin"),
  async (req, res) => {
    const limit = Math.min(Number(req.query.limit || 50), 200);

    const logs = await AdminAuditLog.find()
      .sort({ createdAt: -1 })
      .limit(limit)
      .populate("adminId", "name email")
      .lean();

    res.json({ ok: true, data: logs });
  }
);

module.exports = router;
