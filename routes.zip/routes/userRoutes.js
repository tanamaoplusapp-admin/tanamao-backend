// backend/routes/userRoutes.js
const express = require('express');
const router = express.Router();

// 🔐 middleware padrão do projeto
const { verifyToken } = require('../middleware/verifyToken');

// ✅ controllers que COMPROVADAMENTE existem
const {
  getMe,
  updateMe,
  updateUserAvailability,
  savePushToken
} = require('../controllers/userController');

// Perfil do usuário logado
router.get('/profile', verifyToken, getMe);
router.put('/profile', verifyToken, updateMe);

// 🔌 Disponibilidade online/offline (global)
router.patch('/availability', verifyToken, updateUserAvailability);

// 🔔 salvar token de push do dispositivo
router.post('/push-token', verifyToken, savePushToken);

module.exports = router;