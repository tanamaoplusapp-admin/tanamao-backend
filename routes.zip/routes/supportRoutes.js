// routes/supportRoutes.js
const express = require('express');
const router = express.Router();

let verifyModule = null;
try { verifyModule = require('../middleware/verifyToken'); } catch {}
const verifyToken =
  (typeof verifyModule === 'function')
    ? verifyModule
    : (verifyModule && typeof verifyModule.verifyToken === 'function')
      ? verifyModule.verifyToken
      : (_req, _res, next) => next();

let ctrl = {};
try { ctrl = require('../controllers/supportController'); } catch { ctrl = {}; }

const h = (fn) => (req, res, next) =>
  (typeof fn === 'function' ? fn(req, res, next) : res.status(501).json({ message: 'Not implemented' }));

const maybeAuth = (req, res, next) => {
  if (!req.headers.authorization) return next();
  return verifyToken(req, res, next);
};

// Criação de ticket (público ou usuário)
router.post('/tickets', maybeAuth, h(ctrl.create));

// Listagem de tickets (admin ou usuário)
router.get('/tickets', verifyToken, h(ctrl.list));

// Detalhe de ticket
router.get('/tickets/:id', verifyToken, h(ctrl.get));

// Responder ticket
router.post('/tickets/:id/reply', verifyToken, h(ctrl.reply));

// Fechar ticket
router.patch('/tickets/:id/close', verifyToken, h(ctrl.close));

module.exports = router;
