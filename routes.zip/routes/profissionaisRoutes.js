const express = require('express');
const router = express.Router();

/* ================= AUTH (FIX DEFINITIVO) ================= */
let verifyToken;
try {
  const auth = require('../middleware/verifyToken');
  verifyToken = auth.verifyToken;
} catch (_) {
  try {
    const auth = require('../middleware/authMiddleware');
    verifyToken = auth.verifyToken || auth;
  } catch (_) {
    verifyToken = null;
  }
}

if (typeof verifyToken !== 'function') {
  verifyToken = (_req, _res, next) => next();
}

/* ================= CONTROLLERS ================= */
const ctrl = require('../controllers/profissionaisController');
const solicitacoesCtrl = require('../controllers/solicitacoesController');
const ofertaCtrl = require('../controllers/ofertaController');

/* ================= ROTAS ================= */

// 🌍 PÚBLICOS
router.get('/', ctrl.list);

// 🔒 AUTENTICADOS (antes de /:id)
router.get('/me', verifyToken, ctrl.getMe);
router.put('/me', verifyToken, ctrl.updateMe);
router.put('/me/banco', verifyToken, ctrl.updateBank);

router.get(
  '/me/resumo',
  verifyToken,
  ctrl.getResumoProfissionalLogado
);

// ⚠️ LEGADO (compatibilidade)
router.patch('/me/status', verifyToken, ctrl.updateStatus);

// 📦 Solicitações por profissional
router.get('/:id/solicitacoes', verifyToken, solicitacoesCtrl.listByProfissional);

/* ================= OFERTAS ================= */

// 🔒 Criar oferta
router.post('/:id/ofertas', verifyToken, ofertaCtrl.criar);

// 🌍 Listar ofertas (público)
router.get('/:id/ofertas', ofertaCtrl.listarPorProfissional);

// 🔒 Atualizar oferta
router.patch('/:id/ofertas/:ofertaId', verifyToken, ofertaCtrl.atualizar);

// 🔒 Excluir oferta
router.delete('/:id/ofertas/:ofertaId', verifyToken, ofertaCtrl.excluir);

/* ================= PERFIL PÚBLICO (SEMPRE POR ÚLTIMO) ================= */

router.get('/:id', ctrl.getById);

module.exports = router;