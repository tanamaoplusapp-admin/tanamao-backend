// routes/servicoRoutes.js
const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/servicoController');

// 🔐 AUTH REAL
const authMiddleware = require('../middlewares/authMiddleware');

// ==========================
// ORDEM IMPORTA!
// Rotas específicas antes de /:id
// ==========================

// Listagens
router.get('/cliente/:clienteId', authMiddleware, ctrl.listByCliente);
router.get('/profissional/:profissionalId', authMiddleware, ctrl.listByProfissional);

// Cria solicitação
router.post('/', authMiddleware, ctrl.createService);

// Atualiza status
router.put('/:id/status', authMiddleware, ctrl.updateStatus);

// Atualiza progresso/localização
router.put('/:id/progress', authMiddleware, ctrl.updateProgress);

// Busca por ID (deixar por último)
router.get('/:id', authMiddleware, ctrl.getServiceById);

module.exports = router;